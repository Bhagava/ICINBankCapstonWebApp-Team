import { Chequebook } from './chequebook';

describe('Chequebook', () => {
  it('should create an instance', () => {
    expect(new Chequebook()).toBeTruthy();
  });
});

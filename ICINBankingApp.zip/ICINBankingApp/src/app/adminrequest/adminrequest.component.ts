import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminrequest',
  templateUrl: './adminrequest.component.html',
  styleUrls: ['./adminrequest.component.css']
})
export class AdminrequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

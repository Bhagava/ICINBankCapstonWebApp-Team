export class User {
    id:number;
    fullname: string;
    surname: string;
    mailid: string;
    phonenumber: number;
    address: string;
    password: string;
    status: string;



    // constructor(
    // Fullname: string,
    // Surname: string,
    // mailid: string,
    // phonenumber: number,
    // Address: string,
    // password: string,
    // ){
    // }

    // id:number;
    
    constructor()
    {

    }
    // constructor(Fullname:string, Surname:string, mailid:string,phonenumber:number,Address:string, password:string)
    // {
    //     // this.id = id;
    //     this.Fullname = Fullname;
    //     this.Surname=Surname;
    //     this.mailid = mailid;
    //     this.phonenumber= phonenumber;
    //     this.Address=Address;
    //     this.password=password;
    // }
}

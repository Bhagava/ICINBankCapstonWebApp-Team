export class Admin {
    emailid:string;
    password:string;

    // Admin(){
        
    // }
}

import {User} from './user'


export class Chequebook {
    description:string;
    userid = sessionStorage.getItem("id");

    constructor()
    {
        
    }
}

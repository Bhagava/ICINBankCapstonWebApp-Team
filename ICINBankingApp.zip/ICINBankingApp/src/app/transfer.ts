export class Transfer {



    description:string;
    transactionAmount: number;
    sourceAccountnumber: number
    destinationAccountnumber: number
    IFSC:string
    constructor(
        
    )
    {
    }
}
